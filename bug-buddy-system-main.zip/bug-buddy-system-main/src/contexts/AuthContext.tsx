import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { User as SupabaseUser, Session } from '@supabase/supabase-js';

export type UserRole = 'admin' | 'tester' | 'developer';

export interface AppUser {
  id: string;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  role: UserRole;
}

export interface BugRow {
  id: string;
  title: string;
  description: string;
  priority: string;
  status: string;
  reporter_id: string;
  assignee_id: string | null;
  created_at: string;
  updated_at: string;
  reporter_username?: string;
  assignee_username?: string;
}

interface AuthContextType {
  user: AppUser | null;
  loading: boolean;
  bugs: BugRow[];
  bugsLoading: boolean;
  login: (email: string, password: string) => Promise<string | null>;
  signup: (email: string, password: string, username: string, role: UserRole) => Promise<string | null>;
  logout: () => Promise<void>;
  addBug: (bug: { title: string; description: string; priority: string }) => Promise<string | null>;
  updateBugStatus: (bugId: string, status: string) => Promise<string | null>;
  assignBug: (bugId: string, assigneeId: string) => Promise<string | null>;
  refreshBugs: () => Promise<void>;
  developers: { id: string; username: string }[];
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [bugs, setBugs] = useState<BugRow[]>([]);
  const [bugsLoading, setBugsLoading] = useState(false);
  const [developers, setDevelopers] = useState<{ id: string; username: string }[]>([]);

  const fetchProfile = useCallback(async (supaUser: SupabaseUser): Promise<AppUser | null> => {
    const { data: profile } = await supabase
      .from('profiles')
      .select('username, display_name, avatar_url')
      .eq('id', supaUser.id)
      .single();

    const { data: roleData } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', supaUser.id)
      .single();

    if (!profile || !roleData) return null;

    return {
      id: supaUser.id,
      username: profile.username,
      displayName: profile.display_name,
      avatarUrl: profile.avatar_url,
      role: roleData.role as UserRole,
    };
  }, []);

  const fetchBugs = useCallback(async () => {
    setBugsLoading(true);
    // Fetch bugs with reporter and assignee usernames
    const { data: bugsData } = await supabase
      .from('bugs')
      .select('*')
      .order('created_at', { ascending: false });

    if (bugsData) {
      // Get unique user IDs
      const userIds = new Set<string>();
      bugsData.forEach((b: any) => {
        userIds.add(b.reporter_id);
        if (b.assignee_id) userIds.add(b.assignee_id);
      });

      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username')
        .in('id', Array.from(userIds));

      const profileMap = new Map(profiles?.map((p: any) => [p.id, p.username]) || []);

      setBugs(
        bugsData.map((b: any) => ({
          ...b,
          reporter_username: profileMap.get(b.reporter_id) || 'Unknown',
          assignee_username: b.assignee_id ? profileMap.get(b.assignee_id) || 'Unknown' : undefined,
        }))
      );
    }
    setBugsLoading(false);
  }, []);

  const fetchDevelopers = useCallback(async () => {
    const { data } = await supabase
      .from('user_roles')
      .select('user_id')
      .eq('role', 'developer');

    if (data && data.length > 0) {
      const ids = data.map((d: any) => d.user_id);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, username')
        .in('id', ids);
      setDevelopers(profiles?.map((p: any) => ({ id: p.id, username: p.username })) || []);
    }
  }, []);

  // Auth state listener
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        const appUser = await fetchProfile(session.user);
        setUser(appUser);
      } else {
        setUser(null);
        setBugs([]);
      }
      setLoading(false);
    });

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session?.user) {
        const appUser = await fetchProfile(session.user);
        setUser(appUser);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [fetchProfile]);

  // Load bugs & developers when user is authenticated
  useEffect(() => {
    if (user) {
      fetchBugs();
      fetchDevelopers();
    }
  }, [user, fetchBugs, fetchDevelopers]);

  const login = useCallback(async (email: string, password: string): Promise<string | null> => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return error ? error.message : null;
  }, []);

  const signup = useCallback(async (email: string, password: string, username: string, role: UserRole): Promise<string | null> => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: window.location.origin,
        data: { username, role },
      },
    });
    return error ? error.message : null;
  }, []);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
    setBugs([]);
  }, []);

  const addBug = useCallback(async (bugData: { title: string; description: string; priority: string }): Promise<string | null> => {
    if (!user) return 'Not authenticated';
    const { error } = await supabase.from('bugs').insert({
      id: '', // trigger will generate
      title: bugData.title,
      description: bugData.description,
      priority: bugData.priority,
      status: 'open',
      reporter_id: user.id,
    });
    if (error) return error.message;
    await fetchBugs();
    return null;
  }, [user, fetchBugs]);

  const updateBugStatus = useCallback(async (bugId: string, status: string): Promise<string | null> => {
    const { error } = await supabase.from('bugs').update({ status }).eq('id', bugId);
    if (error) return error.message;
    await fetchBugs();
    return null;
  }, [fetchBugs]);

  const assignBug = useCallback(async (bugId: string, assigneeId: string): Promise<string | null> => {
    const { error } = await supabase.from('bugs').update({ assignee_id: assigneeId }).eq('id', bugId);
    if (error) return error.message;
    await fetchBugs();
    return null;
  }, [fetchBugs]);

  const refreshBugs = fetchBugs;

  return (
    <AuthContext.Provider value={{ user, loading, bugs, bugsLoading, login, signup, logout, addBug, updateBugStatus, assignBug, refreshBugs, developers }}>
      {children}
    </AuthContext.Provider>
  );
};
