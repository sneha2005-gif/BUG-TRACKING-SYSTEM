import React, { useState, useRef, useEffect } from 'react';
import { useAuth, BugRow } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { Cpu, Lightbulb, ChevronRight, MessageSquare, Send, Loader2, FileText } from 'lucide-react';
import { PriorityBadge, StatusBadge } from '@/pages/Dashboard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ReactMarkdown from 'react-markdown';
import { toast } from '@/hooks/use-toast';

const AI_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-assistant`;

type ChatMsg = { role: 'user' | 'assistant'; content: string };

const AIDebug: React.FC = () => {
  const { bugs, user } = useAuth();
  const [selectedBugId, setSelectedBugId] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<string | null>(null);
  const [suggestionsLoading, setSuggestionsLoading] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMsg[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const assignedBugs = bugs.filter((b) => b.assignee_id === user?.id && b.status !== 'resolved');
  const selectedBug = bugs.find((b) => b.id === selectedBugId);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const fetchAI = async (type: 'debug' | 'summary', bug: BugRow) => {
    const setter = type === 'debug' ? setSuggestions : setSummary;
    const setLoading = type === 'debug' ? setSuggestionsLoading : setSummaryLoading;
    setLoading(true);
    setter(null);
    try {
      const resp = await fetch(AI_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ type, bug: { title: bug.title, description: bug.description, priority: bug.priority, status: bug.status } }),
      });
      if (!resp.ok) {
        const err = await resp.json();
        throw new Error(err.error || 'AI request failed');
      }
      const data = await resp.json();
      setter(data.content);
    } catch (e: any) {
      toast({ title: 'AI Error', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleSelectBug = (bug: BugRow) => {
    setSelectedBugId(bug.id);
    setSuggestions(null);
    setSummary(null);
    setChatMessages([{ role: 'assistant', content: `I'm ready to help you debug **${bug.title}**. Ask me anything about this bug!` }]);
    fetchAI('debug', bug);
    fetchAI('summary', bug);
  };

  const sendChat = async () => {
    if (!chatInput.trim() || !selectedBug || chatLoading) return;
    const userMsg: ChatMsg = { role: 'user', content: chatInput };
    const newMessages = [...chatMessages, userMsg];
    setChatMessages(newMessages);
    setChatInput('');
    setChatLoading(true);

    let assistantSoFar = '';
    const bugContext = `[Context: Bug "${selectedBug.title}" - ${selectedBug.description} | Priority: ${selectedBug.priority} | Status: ${selectedBug.status}]`;

    try {
      const resp = await fetch(AI_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          type: 'chat',
          messages: [
            { role: 'user', content: bugContext },
            ...newMessages,
          ],
        }),
      });

      if (!resp.ok) {
        const err = await resp.json();
        throw new Error(err.error || 'Chat failed');
      }

      const reader = resp.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let newlineIdx: number;
        while ((newlineIdx = buffer.indexOf('\n')) !== -1) {
          let line = buffer.slice(0, newlineIdx);
          buffer = buffer.slice(newlineIdx + 1);
          if (line.endsWith('\r')) line = line.slice(0, -1);
          if (!line.startsWith('data: ')) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === '[DONE]') break;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              assistantSoFar += content;
              setChatMessages(prev => {
                const last = prev[prev.length - 1];
                if (last?.role === 'assistant' && prev.length > newMessages.length) {
                  return prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantSoFar } : m);
                }
                return [...prev, { role: 'assistant', content: assistantSoFar }];
              });
            }
          } catch { /* partial JSON */ }
        }
      }
    } catch (e: any) {
      toast({ title: 'Chat Error', description: e.message, variant: 'destructive' });
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="p-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-3 mb-1">
          <Cpu className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold text-foreground">AI Debug Analysis</h1>
        </div>
        <p className="text-muted-foreground mb-8">Select a bug to get AI-powered debugging suggestions, summaries, and chat assistance.</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Bug list */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
          <h2 className="text-sm font-medium text-muted-foreground mb-3">Your Active Bugs</h2>
          <div className="space-y-2">
            {assignedBugs.map((bug) => (
              <button key={bug.id} onClick={() => handleSelectBug(bug)} className={`w-full text-left rounded-xl border p-4 transition-all ${selectedBugId === bug.id ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/30'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-mono text-muted-foreground">{bug.id}</p>
                    <p className="font-medium text-foreground truncate">{bug.title}</p>
                  </div>
                  <div className="flex items-center gap-2 ml-3">
                    <PriorityBadge priority={bug.priority} />
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              </button>
            ))}
            {assignedBugs.length === 0 && (
              <div className="rounded-xl border border-border bg-card p-8 text-center">
                <p className="text-muted-foreground">No active bugs assigned to you.</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* AI panels */}
        <motion.div className="lg:col-span-2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
          {selectedBug ? (
            <Tabs defaultValue="suggestions" className="w-full">
              <div className="flex items-center gap-3 mb-4">
                <StatusBadge status={selectedBug.status} />
                <PriorityBadge priority={selectedBug.priority} />
                <h3 className="font-semibold text-foreground truncate">{selectedBug.title}</h3>
              </div>
              <TabsList className="mb-4">
                <TabsTrigger value="suggestions" className="gap-2"><Lightbulb className="h-3.5 w-3.5" />Debug Tips</TabsTrigger>
                <TabsTrigger value="summary" className="gap-2"><FileText className="h-3.5 w-3.5" />Summary</TabsTrigger>
                <TabsTrigger value="chat" className="gap-2"><MessageSquare className="h-3.5 w-3.5" />Chat</TabsTrigger>
              </TabsList>

              <TabsContent value="suggestions">
                <div className="rounded-xl border border-border bg-card p-6">
                  {suggestionsLoading ? (
                    <div className="flex items-center gap-2 text-muted-foreground py-8 justify-center">
                      <Loader2 className="h-4 w-4 animate-spin" /> Analyzing bug...
                    </div>
                  ) : suggestions ? (
                    <div className="prose prose-sm max-w-none text-foreground">
                      <ReactMarkdown>{suggestions}</ReactMarkdown>
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-8">No suggestions yet.</p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="summary">
                <div className="rounded-xl border border-border bg-card p-6">
                  {summaryLoading ? (
                    <div className="flex items-center gap-2 text-muted-foreground py-8 justify-center">
                      <Loader2 className="h-4 w-4 animate-spin" /> Generating summary...
                    </div>
                  ) : summary ? (
                    <div className="prose prose-sm max-w-none text-foreground">
                      <ReactMarkdown>{summary}</ReactMarkdown>
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-8">No summary yet.</p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="chat">
                <div className="rounded-xl border border-border bg-card flex flex-col h-[500px]">
                  <div className="flex-1 overflow-auto p-4 space-y-3">
                    {chatMessages.map((msg, i) => (
                      <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-lg px-4 py-2 text-sm ${msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`}>
                          {msg.role === 'assistant' ? (
                            <div className="prose prose-sm max-w-none">
                              <ReactMarkdown>{msg.content}</ReactMarkdown>
                            </div>
                          ) : msg.content}
                        </div>
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>
                  <div className="border-t border-border p-3 flex gap-2">
                    <input
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && sendChat()}
                      placeholder="Ask about this bug..."
                      className="flex-1 bg-muted rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-primary"
                      disabled={chatLoading}
                    />
                    <Button size="icon" onClick={sendChat} disabled={chatLoading || !chatInput.trim()}>
                      {chatLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          ) : (
            <div className="rounded-xl border border-dashed border-border bg-muted/30 p-12 text-center">
              <Cpu className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Select a bug to see AI-powered analysis.</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default AIDebug;
