import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { PriorityBadge, StatusBadge } from '@/pages/Dashboard';
import { motion } from 'framer-motion';
import { ArrowLeft, Calendar, User } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

const BugDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { bugs, user, updateBugStatus, assignBug, developers } = useAuth();

  const bug = bugs.find((b) => b.id === id);

  if (!bug) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Bug not found.</p>
      </div>
    );
  }

  const canUpdateStatus = user?.role === 'developer' || user?.role === 'admin';
  const canAssign = user?.role === 'admin';

  const handleStatusChange = async (status: string) => {
    const error = await updateBugStatus(bug.id, status);
    if (error) {
      toast.error(error);
    } else {
      toast.success(`Status updated to ${status.replace('_', ' ')}`);
    }
  };

  const handleAssign = async (assigneeId: string) => {
    const error = await assignBug(bug.id, assigneeId);
    if (error) {
      toast.error(error);
    } else {
      const dev = developers.find(d => d.id === assigneeId);
      toast.success(`Bug assigned to ${dev?.username || 'developer'}`);
    }
  };

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
    });

  return (
    <div className="p-8 max-w-3xl">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <Link to="/bugs" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4" /> Back to bugs
        </Link>

        <div className="flex items-start justify-between mb-6">
          <div>
            <p className="text-sm font-mono text-muted-foreground mb-1">{bug.id}</p>
            <h1 className="text-2xl font-bold text-foreground">{bug.title}</h1>
          </div>
          <div className="flex gap-2">
            <PriorityBadge priority={bug.priority} />
            <StatusBadge status={bug.status} />
          </div>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="space-y-6">
        <div className="rounded-xl border border-border bg-card p-6">
          <h2 className="text-sm font-medium text-muted-foreground mb-3">Description</h2>
          <p className="text-foreground leading-relaxed">{bug.description}</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <User className="h-4 w-4" /> Reporter
            </div>
            <p className="font-medium text-foreground">{bug.reporter_username || 'Unknown'}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <Calendar className="h-4 w-4" /> Created
            </div>
            <p className="font-medium text-foreground">{formatDate(bug.created_at)}</p>
          </div>
        </div>

        {(canUpdateStatus || canAssign) && (
          <div className="rounded-xl border border-border bg-card p-6 space-y-4">
            <h2 className="text-sm font-medium text-muted-foreground">Actions</h2>
            {canUpdateStatus && (
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">Update Status</label>
                <Select value={bug.status} onValueChange={handleStatusChange}>
                  <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            {canAssign && (
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">Assign to Developer</label>
                <Select value={bug.assignee_id || ''} onValueChange={handleAssign}>
                  <SelectTrigger className="w-[200px]"><SelectValue placeholder="Select developer" /></SelectTrigger>
                  <SelectContent>
                    {developers.map((d) => (
                      <SelectItem key={d.id} value={d.id}>{d.username}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default BugDetail;
