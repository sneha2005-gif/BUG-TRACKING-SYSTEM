import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { Bug, AlertCircle, Clock, CheckCircle2 } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const Dashboard: React.FC = () => {
  const { user, bugs } = useAuth();

  const stats = [
    { label: 'Total Bugs', value: bugs.length, icon: Bug, gradient: 'gradient-card-1', iconColor: 'text-primary' },
    { label: 'Open', value: bugs.filter((b) => b.status === 'open').length, icon: AlertCircle, gradient: 'gradient-card-4', iconColor: 'text-status-open' },
    { label: 'In Progress', value: bugs.filter((b) => b.status === 'in_progress').length, icon: Clock, gradient: 'gradient-card-2', iconColor: 'text-status-progress' },
    { label: 'Resolved', value: bugs.filter((b) => b.status === 'resolved').length, icon: CheckCircle2, gradient: 'gradient-card-3', iconColor: 'text-status-resolved' },
  ];

  const recentBugs = bugs.slice(0, 5);
  const roleLabel = user?.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : '';

  return (
    <div className="p-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Welcome back, {user?.username}</h1>
        <p className="text-muted-foreground mt-1">{roleLabel} Dashboard — Here's your bug overview</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, i) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className={`rounded-xl border border-border p-5 ${stat.gradient}`}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-muted-foreground">{stat.label}</span>
              <stat.icon className={`h-5 w-5 ${stat.iconColor}`} />
            </div>
            <div className="text-3xl font-bold text-foreground">{stat.value}</div>
          </motion.div>
        ))}
      </div>

      {/* Priority Distribution Chart */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }} className="mb-8 rounded-xl border border-border bg-card p-6">
        <h2 className="text-lg font-semibold text-foreground mb-4">Priority Distribution</h2>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={[
                  { name: 'High', value: bugs.filter(b => b.priority === 'high').length },
                  { name: 'Medium', value: bugs.filter(b => b.priority === 'medium').length },
                  { name: 'Low', value: bugs.filter(b => b.priority === 'low').length },
                ]}
                cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={4} dataKey="value" stroke="none"
              >
                <Cell fill="hsl(var(--priority-high))" />
                <Cell fill="hsl(var(--priority-medium))" />
                <Cell fill="hsl(var(--priority-low))" />
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', color: 'hsl(var(--foreground))' }} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Recent bugs */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <h2 className="text-lg font-semibold text-foreground mb-4">Recent Bugs</h2>
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">ID</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Title</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Priority</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Reporter</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {recentBugs.map((bug) => (
                <tr key={bug.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 text-sm font-mono text-muted-foreground">{bug.id}</td>
                  <td className="px-4 py-3 text-sm font-medium text-foreground">{bug.title}</td>
                  <td className="px-4 py-3"><PriorityBadge priority={bug.priority} /></td>
                  <td className="px-4 py-3"><StatusBadge status={bug.status} /></td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{bug.reporter_username || 'Unknown'}</td>
                </tr>
              ))}
              {recentBugs.length === 0 && (
                <tr><td colSpan={5} className="px-4 py-12 text-center text-muted-foreground">No bugs yet. Report one to get started!</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
};

const PriorityBadge: React.FC<{ priority: string }> = ({ priority }) => {
  const styles: Record<string, string> = {
    high: 'bg-priority-high/10 text-priority-high',
    medium: 'bg-priority-medium/10 text-priority-medium',
    low: 'bg-priority-low/10 text-priority-low',
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${styles[priority] || ''}`}>
      {priority.charAt(0).toUpperCase() + priority.slice(1)}
    </span>
  );
};

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const styles: Record<string, string> = {
    open: 'bg-status-open/10 text-status-open',
    in_progress: 'bg-status-progress/10 text-status-progress',
    resolved: 'bg-status-resolved/10 text-status-resolved',
  };
  const labels: Record<string, string> = { open: 'Open', in_progress: 'In Progress', resolved: 'Resolved' };
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${styles[status] || ''}`}>
      {labels[status] || status}
    </span>
  );
};

export { PriorityBadge, StatusBadge };
export default Dashboard;
