import React, { useState } from 'react';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { Bug, Eye, EyeOff, UserPlus, LogIn } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import loginHero from '@/assets/login-hero.jpg';

const Login: React.FC = () => {
  const { login, signup } = useAuth();
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [role, setRole] = useState<UserRole>('tester');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    if (isSignup && !username.trim()) {
      toast.error('Please enter a username');
      return;
    }

    setSubmitting(true);
    let error: string | null;

    if (isSignup) {
      error = await signup(email.trim(), password, username.trim(), role);
      if (!error) {
        toast.success('Account created! Please check your email to verify your account before signing in.');
        setIsSignup(false);
        setSubmitting(false);
        return;
      }
    } else {
      error = await login(email.trim(), password);
      if (!error) {
        toast.success('Signed in successfully');
      }
    }

    if (error) {
      toast.error(error);
    }
    setSubmitting(false);
  };

  return (
    <div className="flex min-h-screen">
      {/* Hero side */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="hidden lg:flex lg:w-1/2 relative items-center justify-center"
      >
        <img src={loginHero} alt="Bug tracking" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-primary/70" />
        <div className="relative z-10 text-center px-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: 'spring' }}
            className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-foreground/20 backdrop-blur"
          >
            <Bug className="h-8 w-8 text-primary-foreground" />
          </motion.div>
          <h1 className="text-4xl font-bold text-primary-foreground mb-4">BugTracker</h1>
          <p className="text-primary-foreground/80 text-lg">
            Track, manage, and resolve software bugs efficiently with your team.
          </p>
          <div className="mt-10 flex justify-center gap-8">
            {[
              { v: '150+', l: 'Bugs Tracked' },
              { v: '95%', l: 'Resolved' },
              { v: '3', l: 'Team Roles' },
            ].map((s) => (
              <div key={s.l} className="rounded-xl bg-primary-foreground/10 backdrop-blur px-5 py-3">
                <p className="text-2xl font-bold text-primary-foreground">{s.v}</p>
                <p className="text-xs text-primary-foreground/70">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Form side */}
      <div className="flex flex-1 items-center justify-center p-8">
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="w-full max-w-md">
          <h2 className="text-2xl font-bold text-foreground mb-1">
            {isSignup ? 'Create an account' : 'Welcome back'}
          </h2>
          <p className="text-muted-foreground mb-8">
            {isSignup ? 'Sign up to start tracking bugs' : 'Sign in to your account to continue'}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignup && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="johndoe"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Role</Label>
                  <Select value={role} onValueChange={(v) => setRole(v as UserRole)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tester">Tester</SelectItem>
                      <SelectItem value="developer">Developer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? (
                'Please wait...'
              ) : isSignup ? (
                <>
                  <UserPlus className="h-4 w-4 mr-2" /> Sign up
                </>
              ) : (
                <>
                  <LogIn className="h-4 w-4 mr-2" /> Sign in
                </>
              )}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {isSignup ? 'Already have an account?' : "Don't have an account?"}{' '}
            <button
              onClick={() => setIsSignup(!isSignup)}
              className="text-primary font-medium hover:underline"
            >
              {isSignup ? 'Sign in' : 'Sign up'}
            </button>
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;
