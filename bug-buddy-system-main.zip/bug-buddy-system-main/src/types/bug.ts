export type UserRole = 'admin' | 'tester' | 'developer';

export type BugPriority = 'high' | 'medium' | 'low';

export type BugStatus = 'open' | 'in_progress' | 'resolved';

export interface User {
  id: string;
  username: string;
  role: UserRole;
}

export interface Bug {
  id: string;
  title: string;
  description: string;
  priority: BugPriority;
  status: BugStatus;
  reporter: string;
  assignee?: string;
  createdAt: string;
  updatedAt: string;
}
